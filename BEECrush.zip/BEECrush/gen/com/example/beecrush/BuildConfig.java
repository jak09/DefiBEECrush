/** Automatically generated file. DO NOT MODIFY */
package com.example.beecrush;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}