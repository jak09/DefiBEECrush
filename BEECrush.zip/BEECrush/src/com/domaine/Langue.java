package com.domaine;

public class Langue {

}
