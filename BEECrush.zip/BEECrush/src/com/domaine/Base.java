package com.domaine;

public class Base {

	public static Jeu jeu = new Jeu();
	
}
