package com.jeu;

import android.app.Activity;
import android.content.res.Resources;
import android.widget.RelativeLayout;

public class Parametre {

	public static int widthEcran;
	public static int heightEcran;
	
	public static Activity activiteDuJeu;
	public static RelativeLayout layoutDuJeu;
	public static Resources resources;
		
}
