package com.jeu.grille;

public enum Direction {
	HAUT, HAUT_DROITE, DROITE, BAS_DROITE, BAS, BAS_GAUCHE, GAUCHE, HAUT_GAUCHE;
}
